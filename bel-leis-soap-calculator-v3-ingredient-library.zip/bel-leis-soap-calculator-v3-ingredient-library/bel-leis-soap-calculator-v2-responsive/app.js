const oilLibrary = [
  { name: "Olive Oil", sap: 0.134 },
  { name: "Coconut Oil 76°", sap: 0.183 },
  { name: "Lard", sap: 0.138 },
  { name: "Avocado Oil", sap: 0.133 },
  { name: "Castor Oil", sap: 0.128 },
  { name: "Shea Butter", sap: 0.128 },
  { name: "Cocoa Butter", sap: 0.137 },
  { name: "Palm Oil", sap: 0.142 },
  { name: "Sweet Almond Oil", sap: 0.136 },
  { name: "Sunflower Oil", sap: 0.136 },
  { name: "Grapeseed Oil", sap: 0.126 },
  { name: "Mango Butter", sap: 0.137 },
  { name: "Kokum Butter", sap: 0.135 },
  { name: "Jojoba Oil", sap: 0.069 },
  { name: "Custom oil / butter", sap: 0.134, custom: true }
];

const starterRows = [
  { name: "Olive Oil", percent: 40, weight: 380, sap: 0.134 },
  { name: "Coconut Oil 76°", percent: 25, weight: 237.5, sap: 0.183 },
  { name: "Shea Butter", percent: 15, weight: 142.5, sap: 0.128 },
  { name: "Sweet Almond Oil", percent: 10, weight: 95, sap: 0.136 },
  { name: "Castor Oil", percent: 10, weight: 95, sap: 0.128 }
];

const els = {
  recipeForm: document.querySelector("#recipeForm"),
  oilRows: document.querySelector("#oilRows"),
  oilTemplate: document.querySelector("#oilRowTemplate"),
  recipeName: document.querySelector("#recipeName"),
  unitSelect: document.querySelector("#unitSelect"),
  superfat: document.querySelector("#superfat"),
  waterMethod: document.querySelector("#waterMethod"),
  waterRatio: document.querySelector("#waterRatio"),
  lyeConcentration: document.querySelector("#lyeConcentration"),
  waterPercent: document.querySelector("#waterPercent"),
  ratioField: document.querySelector("#ratioField"),
  concentrationField: document.querySelector("#concentrationField"),
  percentField: document.querySelector("#percentField"),
  waterBadge: document.querySelector("#waterBadge"),
  fragranceLoad: document.querySelector("#fragranceLoad"),
  fragranceName: document.querySelector("#fragranceName"),
  batchNotes: document.querySelector("#batchNotes"),
  totalPercent: document.querySelector("#totalPercent"),
  totalOilInputWeight: document.querySelector("#totalOilInputWeight"),
  weightHeading: document.querySelector(".weight-heading"),
  resultRecipeName: document.querySelector("#resultRecipeName"),
  totalOils: document.querySelector("#totalOils"),
  lyeBefore: document.querySelector("#lyeBefore"),
  lyeNeeded: document.querySelector("#lyeNeeded"),
  waterNeeded: document.querySelector("#waterNeeded"),
  fragranceNeeded: document.querySelector("#fragranceNeeded"),
  batterWeight: document.querySelector("#batterWeight"),
  miniDetails: document.querySelector("#miniDetails"),
  warnings: document.querySelector("#warnings"),
  previewContent: document.querySelector("#previewContent"),
  recipePreview: document.querySelector("#recipePreview"),
  savedRecipes: document.querySelector("#savedRecipes"),
  addOil: document.querySelector("#addOil"),
  balanceOils: document.querySelector("#balanceOils"),
  saveRecipe: document.querySelector("#saveRecipe"),
  printRecipe: document.querySelector("#printRecipe"),
  resetRecipe: document.querySelector("#resetRecipe"),
  mobileMenuButton: document.querySelector(".mobile-menu-button"),
  navLinks: document.querySelector("#navLinks")
};

let savedRecipes = loadSavedRecipes();
let lastCalculation = null;
let percentMode = true;

function decimal(value, places = 2) {
  const num = Number(value);
  if (!Number.isFinite(num)) return 0;
  return Number(num.toFixed(places));
}

function formatNumber(value, places = 2) {
  const num = Number(value);
  if (!Number.isFinite(num)) return "0";
  return num.toLocaleString(undefined, {
    minimumFractionDigits: places,
    maximumFractionDigits: places
  });
}

function formatWeight(value, unit, places = 2) {
  return `${formatNumber(value, places)} ${unit}`;
}

function converted(value, unit) {
  if (unit === "g") {
    return `${formatWeight(value / 28.3495, "oz", 2)}`;
  }
  return `${formatWeight(value * 28.3495, "g", 1)}`;
}

function getOilByName(name) {
  return oilLibrary.find(oil => oil.name === name) || oilLibrary[0];
}

function populateOilSelect(select, selectedName) {
  select.innerHTML = "";
  oilLibrary.forEach(oil => {
    const option = document.createElement("option");
    option.value = oil.name;
    option.textContent = oil.name;
    select.appendChild(option);
  });
  select.value = selectedName || oilLibrary[0].name;
}

function addOilRow(rowData = {}) {
  const clone = els.oilTemplate.content.cloneNode(true);
  const row = clone.querySelector("tr");
  const select = clone.querySelector(".oil-select");
  const customInput = clone.querySelector(".custom-oil");
  const percentInput = clone.querySelector(".oil-percent-input");
  const weightInput = clone.querySelector(".oil-weight");
  const sapInput = clone.querySelector(".oil-sap");
  const removeButton = clone.querySelector(".remove-oil");

  populateOilSelect(select, rowData.name || oilLibrary[0].name);

  percentInput.value = rowData.percent ?? 0;
  weightInput.value = rowData.weight ?? 0;
  sapInput.value = rowData.sap ?? getOilByName(select.value).sap;

  if (rowData.customName) {
    select.value = "Custom oil / butter";
    customInput.classList.remove("is-hidden");
    customInput.value = rowData.customName;
  }

  select.addEventListener("change", () => {
    const selectedOil = getOilByName(select.value);
    if (selectedOil.custom) {
      customInput.classList.remove("is-hidden");
      customInput.focus();
    } else {
      customInput.classList.add("is-hidden");
      customInput.value = "";
      sapInput.value = selectedOil.sap;
    }
    calculateAndRender();
  });

  [customInput, percentInput, weightInput, sapInput].forEach(input => {
    input.addEventListener("input", calculateAndRender);
    input.addEventListener("change", calculateAndRender);
  });

  removeButton.addEventListener("click", () => {
    const rows = els.oilRows.querySelectorAll("tr");
    if (rows.length <= 1) {
      showTemporaryWarning("A recipe needs at least one oil or butter row.");
      return;
    }
    row.remove();
    calculateAndRender();
  });

  els.oilRows.appendChild(clone);
  calculateAndRender();
}

function getRows() {
  return [...els.oilRows.querySelectorAll("tr")].map(row => {
    const select = row.querySelector(".oil-select");
    const customInput = row.querySelector(".custom-oil");
    const selectedOil = getOilByName(select.value);
    const customName = !customInput.classList.contains("is-hidden") ? customInput.value.trim() : "";
    return {
      name: selectedOil.custom ? (customName || "Custom oil / butter") : selectedOil.name,
      selectName: selectedOil.name,
      customName,
      percent: Number(row.querySelector(".oil-percent-input").value) || 0,
      weight: Number(row.querySelector(".oil-weight").value) || 0,
      sap: Number(row.querySelector(".oil-sap").value) || 0
    };
  });
}

function setRows(rows) {
  els.oilRows.innerHTML = "";
  rows.forEach(row => addOilRow(row));
  calculateAndRender();
}

function getSettings() {
  return {
    recipeName: els.recipeName.value.trim() || "Untitled Soap Recipe",
    unit: els.unitSelect.value,
    superfat: Number(els.superfat.value) || 0,
    waterMethod: els.waterMethod.value,
    waterRatio: Number(els.waterRatio.value) || 0,
    lyeConcentration: Number(els.lyeConcentration.value) || 0,
    waterPercent: Number(els.waterPercent.value) || 0,
    fragranceLoad: Number(els.fragranceLoad.value) || 0,
    fragranceName: els.fragranceName.value.trim(),
    batchNotes: els.batchNotes.value.trim()
  };
}

function calculateRecipe() {
  const settings = getSettings();
  const rows = getRows();
  const totalOils = rows.reduce((sum, row) => sum + row.weight, 0);
  const totalPercent = rows.reduce((sum, row) => sum + row.percent, 0);
  const lyeBeforeSuperfat = rows.reduce((sum, row) => sum + row.weight * row.sap, 0);
  const lyeAfterSuperfat = lyeBeforeSuperfat * (1 - settings.superfat / 100);

  let water = 0;
  let lyeConcentration = 0;
  let waterRatio = 0;
  let waterAsPercent = 0;

  if (settings.waterMethod === "ratio") {
    water = lyeAfterSuperfat * settings.waterRatio;
    waterRatio = settings.waterRatio;
    lyeConcentration = lyeAfterSuperfat + water > 0 ? (lyeAfterSuperfat / (lyeAfterSuperfat + water)) * 100 : 0;
    waterAsPercent = totalOils > 0 ? (water / totalOils) * 100 : 0;
  }

  if (settings.waterMethod === "concentration") {
    water = settings.lyeConcentration > 0 ? lyeAfterSuperfat * ((100 - settings.lyeConcentration) / settings.lyeConcentration) : 0;
    lyeConcentration = settings.lyeConcentration;
    waterRatio = lyeAfterSuperfat > 0 ? water / lyeAfterSuperfat : 0;
    waterAsPercent = totalOils > 0 ? (water / totalOils) * 100 : 0;
  }

  if (settings.waterMethod === "percent") {
    water = totalOils * (settings.waterPercent / 100);
    waterAsPercent = settings.waterPercent;
    waterRatio = lyeAfterSuperfat > 0 ? water / lyeAfterSuperfat : 0;
    lyeConcentration = lyeAfterSuperfat + water > 0 ? (lyeAfterSuperfat / (lyeAfterSuperfat + water)) * 100 : 0;
  }

  const fragrance = totalOils * (settings.fragranceLoad / 100);
  const batterWeight = totalOils + lyeAfterSuperfat + water + fragrance;

  const warnings = [];
  if (totalOils <= 0) warnings.push("Add oil weights before making a batch.");
  if (Math.abs(totalPercent - 100) > 0.2) warnings.push(`Oil percentages currently total ${formatNumber(totalPercent, 1)}%. Use Balance Oils or adjust to 100%.`);
  if (settings.superfat < 0 || settings.superfat > 20) warnings.push("Superfat should usually stay between 0% and 20%.");
  if (settings.fragranceLoad > 6) warnings.push("Fragrance load is above 6%. Check the fragrance supplier and IFRA limit before using it.");
  if (lyeConcentration > 0 && (lyeConcentration < 25 || lyeConcentration > 45)) warnings.push(`Lye concentration is ${formatNumber(lyeConcentration, 1)}%. Many cold process recipes stay around 25%–40%.`);
  if (waterRatio > 0 && (waterRatio < 1.2 || waterRatio > 3.5)) warnings.push(`Water:lye ratio is ${formatNumber(waterRatio, 2)}:1. Double-check that setting.`);
  if (rows.some(row => row.sap <= 0)) warnings.push("One or more SAP values are missing. Every oil/butter needs a NaOH SAP value.");
  if (rows.some(row => row.weight < 0 || row.percent < 0)) warnings.push("Negative oil weights or percentages are not valid.");

  return {
    settings,
    rows,
    totalOils,
    totalPercent,
    lyeBeforeSuperfat,
    lyeAfterSuperfat,
    water,
    fragrance,
    batterWeight,
    lyeConcentration,
    waterRatio,
    waterAsPercent,
    warnings,
    createdAt: new Date().toISOString()
  };
}

function updateWaterUI() {
  const method = els.waterMethod.value;
  els.ratioField.classList.toggle("is-hidden", method !== "ratio");
  els.concentrationField.classList.toggle("is-hidden", method !== "concentration");
  els.percentField.classList.toggle("is-hidden", method !== "percent");
  els.waterBadge.textContent = method === "ratio" ? "Ratio" : method === "concentration" ? "Concentration" : "% of oils";
}

function renderCalculation(calc) {
  const unit = calc.settings.unit;
  const oppositeUnit = unit === "g" ? "oz" : "g";
  const places = unit === "g" ? 1 : 2;
  els.resultRecipeName.textContent = calc.settings.recipeName;
  els.totalOils.textContent = formatWeight(calc.totalOils, unit, places);
  els.lyeBefore.textContent = formatWeight(calc.lyeBeforeSuperfat, unit, places);
  els.lyeNeeded.textContent = formatWeight(calc.lyeAfterSuperfat, unit, places);
  els.waterNeeded.textContent = formatWeight(calc.water, unit, places);
  els.fragranceNeeded.textContent = formatWeight(calc.fragrance, unit, places);
  els.batterWeight.textContent = formatWeight(calc.batterWeight, unit, places);

  els.totalPercent.textContent = `${formatNumber(calc.totalPercent, 1)}%`;
  els.totalOilInputWeight.textContent = `${formatWeight(calc.totalOils, unit, places)}`;
  els.weightHeading.textContent = unit === "g" ? "Grams" : "Ounces";

  els.miniDetails.innerHTML = [
    `Superfat: ${formatNumber(calc.settings.superfat, 1)}%`,
    `Lye concentration: ${formatNumber(calc.lyeConcentration, 1)}%`,
    `Water:lye ratio: ${formatNumber(calc.waterRatio, 2)}:1`,
    `Water as oils: ${formatNumber(calc.waterAsPercent, 1)}%`,
    `${oppositeUnit.toUpperCase()} equivalents included in print`
  ].map(item => `<span>${item}</span>`).join("");

  if (calc.warnings.length) {
    els.warnings.hidden = false;
    els.warnings.innerHTML = calc.warnings.map(warning => `<p>${escapeHtml(warning)}</p>`).join("");
  } else {
    els.warnings.hidden = true;
    els.warnings.innerHTML = "";
  }

  renderPreview(calc);
}

function renderPreview(calc) {
  const unit = calc.settings.unit;
  const places = unit === "g" ? 1 : 2;
  els.recipePreview.querySelector("h3").textContent = calc.settings.recipeName;
  const oilsMarkup = calc.rows.map(row => `
    <tr>
      <td>${escapeHtml(row.name)}</td>
      <td>${formatNumber(row.percent, 1)}%</td>
      <td>${formatWeight(row.weight, unit, places)}</td>
    </tr>
  `).join("");

  const notesMarkup = calc.settings.batchNotes
    ? `<p><strong>Notes:</strong> ${escapeHtml(calc.settings.batchNotes)}</p>`
    : "";

  els.previewContent.innerHTML = `
    <div class="preview-meta">
      <span><strong>Total oils:</strong> ${formatWeight(calc.totalOils, unit, places)} (${converted(calc.totalOils, unit)})</span>
      <span><strong>Superfat:</strong> ${formatNumber(calc.settings.superfat, 1)}%</span>
      <span><strong>NaOH needed:</strong> ${formatWeight(calc.lyeAfterSuperfat, unit, places)} (${converted(calc.lyeAfterSuperfat, unit)})</span>
      <span><strong>Water needed:</strong> ${formatWeight(calc.water, unit, places)} (${converted(calc.water, unit)})</span>
      <span><strong>Fragrance:</strong> ${calc.settings.fragranceName ? `${escapeHtml(calc.settings.fragranceName)} — ` : ""}${formatWeight(calc.fragrance, unit, places)} (${formatNumber(calc.settings.fragranceLoad, 1)}%)</span>
    </div>
    <table class="preview-table">
      <thead><tr><th>Oil / Butter</th><th>%</th><th>${unit === "g" ? "Grams" : "Ounces"}</th></tr></thead>
      <tbody>${oilsMarkup}</tbody>
    </table>
    <div class="preview-meta">
      <span><strong>Lye concentration:</strong> ${formatNumber(calc.lyeConcentration, 1)}%</span>
      <span><strong>Water:lye ratio:</strong> ${formatNumber(calc.waterRatio, 2)}:1</span>
      <span><strong>Estimated batter:</strong> ${formatWeight(calc.batterWeight, unit, places)}</span>
    </div>
    ${notesMarkup}
  `;
}

function calculateAndRender() {
  updateWaterUI();
  lastCalculation = calculateRecipe();
  renderCalculation(lastCalculation);
}

function balanceOilWeights() {
  const rows = [...els.oilRows.querySelectorAll("tr")];
  const totalWeight = rows.reduce((sum, row) => sum + (Number(row.querySelector(".oil-weight").value) || 0), 0);
  const totalPercent = rows.reduce((sum, row) => sum + (Number(row.querySelector(".oil-percent-input").value) || 0), 0);

  if (totalWeight > 0 && totalPercent > 0) {
    rows.forEach(row => {
      const percent = Number(row.querySelector(".oil-percent-input").value) || 0;
      row.querySelector(".oil-weight").value = decimal(totalWeight * percent / 100, 2);
    });
  } else if (rows.length) {
    const equalPercent = decimal(100 / rows.length, 1);
    rows.forEach((row, index) => {
      row.querySelector(".oil-percent-input").value = index === rows.length - 1
        ? decimal(100 - equalPercent * (rows.length - 1), 1)
        : equalPercent;
    });
  }
  calculateAndRender();
}

function resetRecipe() {
  els.recipeName.value = "Lavender Dreams";
  els.unitSelect.value = "g";
  els.superfat.value = "5";
  els.waterMethod.value = "ratio";
  els.waterRatio.value = "2.4";
  els.lyeConcentration.value = "30";
  els.waterPercent.value = "33";
  els.fragranceLoad.value = "5";
  els.fragranceName.value = "Lavender & Chamomile";
  els.batchNotes.value = "";
  setRows(starterRows);
}

function loadSavedRecipes() {
  try {
    return JSON.parse(localStorage.getItem("belLeisSoapRecipes") || "[]");
  } catch {
    return [];
  }
}

function storeSavedRecipes() {
  localStorage.setItem("belLeisSoapRecipes", JSON.stringify(savedRecipes));
}

function saveCurrentRecipe() {
  const calc = calculateRecipe();
  if (calc.totalOils <= 0) {
    showTemporaryWarning("Add oil weights before saving the recipe.");
    return;
  }
  const freeLimit = 3;
  if (savedRecipes.length >= freeLimit) {
    showTemporaryWarning("Free mode saves up to 3 recipes. Delete one saved recipe or treat unlimited saves as a future Pro feature.");
    return;
  }
  savedRecipes.unshift({
    id: crypto.randomUUID ? crypto.randomUUID() : String(Date.now()),
    name: calc.settings.recipeName,
    settings: calc.settings,
    rows: calc.rows,
    totals: {
      totalOils: calc.totalOils,
      lyeAfterSuperfat: calc.lyeAfterSuperfat,
      water: calc.water,
      fragrance: calc.fragrance
    },
    createdAt: calc.createdAt
  });
  storeSavedRecipes();
  renderSavedRecipes();
}

function loadRecipe(recipeId) {
  const recipe = savedRecipes.find(item => item.id === recipeId);
  if (!recipe) return;
  els.recipeName.value = recipe.settings.recipeName || recipe.name;
  els.unitSelect.value = recipe.settings.unit || "g";
  els.superfat.value = recipe.settings.superfat ?? 5;
  els.waterMethod.value = recipe.settings.waterMethod || "ratio";
  els.waterRatio.value = recipe.settings.waterRatio ?? 2.4;
  els.lyeConcentration.value = recipe.settings.lyeConcentration ?? 30;
  els.waterPercent.value = recipe.settings.waterPercent ?? 33;
  els.fragranceLoad.value = recipe.settings.fragranceLoad ?? 5;
  els.fragranceName.value = recipe.settings.fragranceName || "";
  els.batchNotes.value = recipe.settings.batchNotes || "";
  setRows(recipe.rows.map(row => ({
    name: row.selectName || row.name,
    customName: row.customName || "",
    percent: row.percent,
    weight: row.weight,
    sap: row.sap
  })));
  document.querySelector("#calculator").scrollIntoView({ behavior: "smooth" });
}

function deleteRecipe(recipeId) {
  savedRecipes = savedRecipes.filter(item => item.id !== recipeId);
  storeSavedRecipes();
  renderSavedRecipes();
}

function renderSavedRecipes() {
  if (!savedRecipes.length) {
    els.savedRecipes.innerHTML = `<div class="empty-vault">No saved recipes yet. Calculate a recipe, then press “Save recipe.”</div>`;
    return;
  }

  els.savedRecipes.innerHTML = savedRecipes.map(recipe => {
    const unit = recipe.settings.unit || "g";
    const places = unit === "g" ? 1 : 2;
    const date = new Date(recipe.createdAt).toLocaleDateString();
    return `
      <article class="vault-card">
        <h3>${escapeHtml(recipe.name)}</h3>
        <p>${date}</p>
        <p>Total oils: ${formatWeight(recipe.totals.totalOils, unit, places)}</p>
        <p>NaOH: ${formatWeight(recipe.totals.lyeAfterSuperfat, unit, places)} · Water: ${formatWeight(recipe.totals.water, unit, places)}</p>
        <div class="vault-actions">
          <button type="button" data-load="${recipe.id}">Load</button>
          <button type="button" data-delete="${recipe.id}">Delete</button>
        </div>
      </article>
    `;
  }).join("");

  els.savedRecipes.querySelectorAll("[data-load]").forEach(button => {
    button.addEventListener("click", () => loadRecipe(button.dataset.load));
  });

  els.savedRecipes.querySelectorAll("[data-delete]").forEach(button => {
    button.addEventListener("click", () => deleteRecipe(button.dataset.delete));
  });
}

function showTemporaryWarning(message) {
  els.warnings.hidden = false;
  els.warnings.innerHTML = `<p>${escapeHtml(message)}</p>`;
  window.setTimeout(() => calculateAndRender(), 3200);
}

function escapeHtml(value) {
  return String(value)
    .replaceAll("&", "&amp;")
    .replaceAll("<", "&lt;")
    .replaceAll(">", "&gt;")
    .replaceAll('"', "&quot;")
    .replaceAll("'", "&#039;");
}

function bindEvents() {
  els.recipeForm.addEventListener("submit", event => {
    event.preventDefault();
    calculateAndRender();
  });

  [
    els.recipeName,
    els.unitSelect,
    els.superfat,
    els.waterMethod,
    els.waterRatio,
    els.lyeConcentration,
    els.waterPercent,
    els.fragranceLoad,
    els.fragranceName,
    els.batchNotes
  ].forEach(input => {
    input.addEventListener("input", calculateAndRender);
    input.addEventListener("change", calculateAndRender);
  });

  els.addOil.addEventListener("click", () => addOilRow({ name: "Custom oil / butter", percent: 0, weight: 0, sap: 0.134 }));
  els.balanceOils.addEventListener("click", balanceOilWeights);
  els.saveRecipe.addEventListener("click", saveCurrentRecipe);
  els.printRecipe.addEventListener("click", () => window.print());
  els.resetRecipe.addEventListener("click", resetRecipe);

  document.querySelectorAll("[data-scroll-to]").forEach(button => {
    button.addEventListener("click", () => {
      const target = document.querySelector(`#${button.dataset.scrollTo}`);
      if (target) target.scrollIntoView({ behavior: "smooth" });
    });
  });

  els.mobileMenuButton.addEventListener("click", () => {
    const isOpen = els.navLinks.classList.toggle("is-open");
    els.mobileMenuButton.setAttribute("aria-expanded", String(isOpen));
  });

  els.navLinks.querySelectorAll("a").forEach(link => {
    link.addEventListener("click", () => {
      els.navLinks.classList.remove("is-open");
      els.mobileMenuButton.setAttribute("aria-expanded", "false");
    });
  });
}

function registerServiceWorker() {
  if ("serviceWorker" in navigator) {
    navigator.serviceWorker.register("service-worker.js").catch(() => {
      // GitHub Pages may block service workers in some preview contexts. The site still works without it.
    });
  }
}

bindEvents();
setRows(starterRows);
renderSavedRecipes();
calculateAndRender();
registerServiceWorker();
