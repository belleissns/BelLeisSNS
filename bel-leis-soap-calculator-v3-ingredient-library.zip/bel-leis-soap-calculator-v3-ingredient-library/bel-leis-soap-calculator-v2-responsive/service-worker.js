const CACHE_NAME = "bel-leis-soap-calculator-v2";
const ASSETS = [
  "./",
  "./index.html",
  "./styles.css",
  "./app.js",
  "./manifest.webmanifest",
  "./assets/favicon.svg",
  "./assets/potion-mark.svg",
  "./assets/divider-gold.svg",
  "./assets/divider-silver.svg",
  "./assets/floral-sprig.svg",
  "./assets/floral-corner-left.svg",
  "./assets/floral-corner-right.svg",
  "./assets/lavender-mini.svg",
  "./assets/paper-texture.svg"
];

self.addEventListener("install", event => {
  event.waitUntil(caches.open(CACHE_NAME).then(cache => cache.addAll(ASSETS)));
});

self.addEventListener("activate", event => {
  event.waitUntil(
    caches.keys().then(keys => Promise.all(keys.map(key => key !== CACHE_NAME ? caches.delete(key) : null)))
  );
});

self.addEventListener("fetch", event => {
  if (event.request.method !== "GET") return;
  event.respondWith(
    caches.match(event.request).then(cached => cached || fetch(event.request).catch(() => caches.match("./index.html")))
  );
});
