const ingredientLibrary = [
  {
    name: "Olive Oil",
    category: "Oils",
    sapNaoh: 0.134,
    sapKoh: 0.188,
    color: "Pale yellow to green; usually makes a creamy off-white bar.",
    usage: "Common at 20%–80% of oils. High-olive recipes need a longer cure.",
    contributes: ["conditioning", "mildness", "low/slimy lather at high use", "longer cure"],
    qualities: { hardness: "low", cleansing: "low", bubbly: "low", creamy: "medium", conditioning: "high" },
    fattyAcids: { lauric: 0, myristic: 0, palmitic: 12, stearic: 3, ricinoleic: 0, oleic: 72, linoleic: 10, linolenic: 1 },
    iodine: 85,
    notes: "Lovely mild oil, but it does not create much fluffy lather on its own."
  },
  {
    name: "Olive Oil Pomace",
    aliases: ["Pomace Olive Oil"],
    category: "Oils",
    sapNaoh: 0.134,
    sapKoh: 0.188,
    color: "Yellow-green; can deepen natural soap color.",
    usage: "Often 20%–60%. May trace faster than refined olive oil.",
    contributes: ["conditioning", "mildness", "faster trace than refined olive"],
    qualities: { hardness: "low", cleansing: "low", bubbly: "low", creamy: "medium", conditioning: "high" },
    fattyAcids: { lauric: 0, myristic: 0, palmitic: 12, stearic: 3, ricinoleic: 0, oleic: 72, linoleic: 10, linolenic: 1 },
    iodine: 85,
    notes: "Useful in budget recipes, but watch trace speed."
  },
  {
    name: "Coconut Oil 76°",
    aliases: ["Coconut Oil", "76 degree coconut"],
    category: "Oils",
    sapNaoh: 0.183,
    sapKoh: 0.257,
    color: "White to very pale; helps make a whiter bar.",
    usage: "Common at 10%–30%. Very high coconut recipes usually need higher superfat.",
    contributes: ["hardness", "cleansing", "big bubbles", "can feel drying if too high"],
    qualities: { hardness: "high", cleansing: "high", bubbly: "high", creamy: "low", conditioning: "low" },
    fattyAcids: { lauric: 48, myristic: 19, palmitic: 9, stearic: 3, ricinoleic: 0, oleic: 8, linoleic: 2, linolenic: 0 },
    iodine: 10,
    notes: "One of the main fluffy-lather oils. Balance with conditioning oils."
  },
  {
    name: "Coconut Oil 92°",
    category: "Oils",
    sapNaoh: 0.183,
    sapKoh: 0.257,
    color: "White to pale; similar soap behavior to 76° coconut.",
    usage: "Common at 10%–30% of oils.",
    contributes: ["hardness", "cleansing", "big bubbles", "can accelerate trace slightly"],
    qualities: { hardness: "high", cleansing: "high", bubbly: "high", creamy: "low", conditioning: "low" },
    fattyAcids: { lauric: 48, myristic: 19, palmitic: 9, stearic: 3, ricinoleic: 0, oleic: 8, linoleic: 2, linolenic: 0 },
    iodine: 10,
    notes: "Higher melting point, similar SAP and performance."
  },
  {
    name: "Palm Oil",
    category: "Oils",
    sapNaoh: 0.142,
    sapKoh: 0.199,
    color: "Cream to pale yellow; red palm adds orange color.",
    usage: "Common at 15%–40% when used. Fully melt and stir before weighing.",
    contributes: ["hardness", "longevity", "creamy stable lather"],
    qualities: { hardness: "high", cleansing: "low", bubbly: "low", creamy: "high", conditioning: "medium" },
    fattyAcids: { lauric: 0, myristic: 1, palmitic: 44, stearic: 5, ricinoleic: 0, oleic: 39, linoleic: 10, linolenic: 0 },
    iodine: 53,
    notes: "A common vegan hard oil. Some makers avoid it unless sustainably sourced."
  },
  {
    name: "Palm Kernel Oil",
    category: "Oils",
    sapNaoh: 0.176,
    sapKoh: 0.247,
    color: "White to pale; helps make a firm bar.",
    usage: "Often 5%–20%. Similar role to coconut oil.",
    contributes: ["hardness", "cleansing", "bubbly lather"],
    qualities: { hardness: "high", cleansing: "high", bubbly: "high", creamy: "medium", conditioning: "low" },
    fattyAcids: { lauric: 48, myristic: 16, palmitic: 8, stearic: 2, ricinoleic: 0, oleic: 15, linoleic: 2, linolenic: 0 },
    iodine: 20,
    notes: "Can substitute part of coconut in some recipes, but recalculate lye."
  },
  {
    name: "Babassu Oil",
    category: "Oils",
    sapNaoh: 0.175,
    sapKoh: 0.245,
    color: "White to pale.",
    usage: "Often 5%–25%. Popular coconut alternative.",
    contributes: ["hardness", "cleansing", "bubbles", "silky feel"],
    qualities: { hardness: "high", cleansing: "high", bubbly: "high", creamy: "medium", conditioning: "low" },
    fattyAcids: { lauric: 50, myristic: 20, palmitic: 11, stearic: 4, ricinoleic: 0, oleic: 11, linoleic: 2, linolenic: 0 },
    iodine: 15,
    notes: "Luxury alternative for coconut-sensitive recipe designs."
  },
  {
    name: "Lard",
    category: "Fats",
    sapNaoh: 0.138,
    sapKoh: 0.194,
    color: "White to cream; usually makes a pale creamy bar.",
    usage: "Common at 20%–50%.",
    contributes: ["hardness", "creaminess", "longevity", "slow trace"],
    qualities: { hardness: "high", cleansing: "low", bubbly: "low", creamy: "high", conditioning: "medium" },
    fattyAcids: { lauric: 0, myristic: 1, palmitic: 28, stearic: 13, ricinoleic: 0, oleic: 46, linoleic: 6, linolenic: 1 },
    iodine: 57,
    notes: "Excellent for beginner-friendly slow trace and a durable bar."
  },
  {
    name: "Beef Tallow",
    aliases: ["Tallow"],
    category: "Fats",
    sapNaoh: 0.140,
    sapKoh: 0.196,
    color: "White to cream; depends on rendering quality.",
    usage: "Common at 20%–60%.",
    contributes: ["hardness", "longevity", "creamy lather"],
    qualities: { hardness: "high", cleansing: "low", bubbly: "low", creamy: "high", conditioning: "medium" },
    fattyAcids: { lauric: 0, myristic: 3, palmitic: 26, stearic: 22, ricinoleic: 0, oleic: 36, linoleic: 3, linolenic: 1 },
    iodine: 45,
    notes: "Very durable, traditional bar soap fat."
  },
  {
    name: "Castor Oil",
    category: "Oils",
    sapNaoh: 0.128,
    sapKoh: 0.180,
    color: "Clear to pale yellow.",
    usage: "Common at 3%–8%. Too much can make soap sticky or soft.",
    contributes: ["lather support", "bubbles", "creaminess", "humectant feel"],
    qualities: { hardness: "low", cleansing: "low", bubbly: "medium", creamy: "high", conditioning: "medium" },
    fattyAcids: { lauric: 0, myristic: 0, palmitic: 2, stearic: 1, ricinoleic: 90, oleic: 4, linoleic: 4, linolenic: 0 },
    iodine: 86,
    notes: "Small amount makes lather easier to build and hold."
  },
  {
    name: "Avocado Oil",
    category: "Oils",
    sapNaoh: 0.133,
    sapKoh: 0.186,
    color: "Green to golden depending on refinement.",
    usage: "Common at 5%–20%.",
    contributes: ["conditioning", "creaminess", "luxury feel"],
    qualities: { hardness: "low", cleansing: "low", bubbly: "low", creamy: "medium", conditioning: "high" },
    fattyAcids: { lauric: 0, myristic: 0, palmitic: 20, stearic: 1, ricinoleic: 0, oleic: 58, linoleic: 12, linolenic: 1 },
    iodine: 86,
    notes: "A rich conditioning oil; may tint soap pale green if unrefined."
  },
  {
    name: "Sweet Almond Oil",
    category: "Oils",
    sapNaoh: 0.136,
    sapKoh: 0.190,
    color: "Pale yellow.",
    usage: "Common at 5%–20%.",
    contributes: ["conditioning", "silky feel", "mildness"],
    qualities: { hardness: "low", cleansing: "low", bubbly: "low", creamy: "low", conditioning: "high" },
    fattyAcids: { lauric: 0, myristic: 0, palmitic: 7, stearic: 2, ricinoleic: 0, oleic: 69, linoleic: 17, linolenic: 0 },
    iodine: 98,
    notes: "Good luxury oil, but keep an eye on high-unsaturated recipes."
  },
  {
    name: "Sunflower Oil",
    category: "Oils",
    sapNaoh: 0.136,
    sapKoh: 0.190,
    color: "Pale yellow.",
    usage: "Often 5%–20%; high-linoleic versions can shorten shelf life.",
    contributes: ["conditioning", "silky feel", "softness"],
    qualities: { hardness: "low", cleansing: "low", bubbly: "low", creamy: "low", conditioning: "high" },
    fattyAcids: { lauric: 0, myristic: 0, palmitic: 6, stearic: 4, ricinoleic: 0, oleic: 20, linoleic: 63, linolenic: 0 },
    iodine: 125,
    notes: "High linoleic can be beautiful but more oxidation-prone. High oleic sunflower is usually sturdier."
  },
  {
    name: "High Oleic Sunflower Oil",
    category: "Oils",
    sapNaoh: 0.136,
    sapKoh: 0.190,
    color: "Pale yellow.",
    usage: "Often 10%–40% as an olive-like conditioning oil.",
    contributes: ["conditioning", "mildness", "slower trace"],
    qualities: { hardness: "low", cleansing: "low", bubbly: "low", creamy: "low", conditioning: "high" },
    fattyAcids: { lauric: 0, myristic: 0, palmitic: 4, stearic: 4, ricinoleic: 0, oleic: 80, linoleic: 9, linolenic: 0 },
    iodine: 85,
    notes: "A good affordable slow-trace conditioning oil."
  },
  {
    name: "Safflower Oil",
    category: "Oils",
    sapNaoh: 0.136,
    sapKoh: 0.190,
    color: "Pale yellow.",
    usage: "Often 5%–20%; use high oleic when possible for longer shelf life.",
    contributes: ["conditioning", "softness"],
    qualities: { hardness: "low", cleansing: "low", bubbly: "low", creamy: "low", conditioning: "high" },
    fattyAcids: { lauric: 0, myristic: 0, palmitic: 7, stearic: 2, ricinoleic: 0, oleic: 14, linoleic: 75, linolenic: 0 },
    iodine: 145,
    notes: "High linoleic safflower can increase DOS risk in high amounts."
  },
  {
    name: "Canola Oil",
    category: "Oils",
    sapNaoh: 0.133,
    sapKoh: 0.187,
    color: "Pale yellow.",
    usage: "Often 5%–20% in budget recipes.",
    contributes: ["conditioning", "softness", "slower trace"],
    qualities: { hardness: "low", cleansing: "low", bubbly: "low", creamy: "low", conditioning: "high" },
    fattyAcids: { lauric: 0, myristic: 0, palmitic: 4, stearic: 2, ricinoleic: 0, oleic: 61, linoleic: 21, linolenic: 9 },
    iodine: 110,
    notes: "Affordable, but high linolenic can be more oxidation-prone."
  },
  {
    name: "Rice Bran Oil",
    category: "Oils",
    sapNaoh: 0.128,
    sapKoh: 0.180,
    color: "Golden yellow.",
    usage: "Often 10%–30% as part olive substitute.",
    contributes: ["conditioning", "creaminess", "silky feel"],
    qualities: { hardness: "low", cleansing: "low", bubbly: "low", creamy: "medium", conditioning: "high" },
    fattyAcids: { lauric: 0, myristic: 1, palmitic: 20, stearic: 2, ricinoleic: 0, oleic: 42, linoleic: 32, linolenic: 1 },
    iodine: 100,
    notes: "Nice creamy conditioning oil; can make batter feel silkier."
  },
  {
    name: "Grapeseed Oil",
    category: "Oils",
    sapNaoh: 0.126,
    sapKoh: 0.177,
    color: "Light green to pale yellow.",
    usage: "Usually 5%–10% because it is high in linoleic acid.",
    contributes: ["conditioning", "light feel", "softness"],
    qualities: { hardness: "low", cleansing: "low", bubbly: "low", creamy: "low", conditioning: "high" },
    fattyAcids: { lauric: 0, myristic: 0, palmitic: 7, stearic: 4, ricinoleic: 0, oleic: 16, linoleic: 70, linolenic: 0 },
    iodine: 135,
    notes: "Lovely, but use modestly to reduce rancidity risk."
  },
  {
    name: "Hemp Seed Oil",
    category: "Oils",
    sapNaoh: 0.135,
    sapKoh: 0.190,
    color: "Green to deep green.",
    usage: "Often 3%–10%. Best in small luxury amounts.",
    contributes: ["conditioning", "green color", "softness"],
    qualities: { hardness: "low", cleansing: "low", bubbly: "low", creamy: "low", conditioning: "high" },
    fattyAcids: { lauric: 0, myristic: 0, palmitic: 6, stearic: 2, ricinoleic: 0, oleic: 12, linoleic: 57, linolenic: 19 },
    iodine: 160,
    notes: "Very high in polyunsaturated fats; small percentages are safer for shelf life."
  },
  {
    name: "Shea Butter",
    category: "Butters",
    sapNaoh: 0.128,
    sapKoh: 0.179,
    color: "Ivory to pale yellow, depending on refinement.",
    usage: "Common at 5%–20%.",
    contributes: ["hardness", "creaminess", "conditioning", "luxury feel"],
    qualities: { hardness: "medium", cleansing: "low", bubbly: "low", creamy: "high", conditioning: "high" },
    fattyAcids: { lauric: 0, myristic: 0, palmitic: 4, stearic: 42, ricinoleic: 0, oleic: 45, linoleic: 6, linolenic: 0 },
    iodine: 59,
    notes: "A beloved butter for creamy, luxurious bars."
  },
  {
    name: "Cocoa Butter",
    category: "Butters",
    sapNaoh: 0.137,
    sapKoh: 0.193,
    color: "Cream to pale yellow; natural cocoa scent possible.",
    usage: "Often 5%–15%. Too much can make soap brittle.",
    contributes: ["hardness", "longevity", "creaminess"],
    qualities: { hardness: "high", cleansing: "low", bubbly: "low", creamy: "high", conditioning: "medium" },
    fattyAcids: { lauric: 0, myristic: 0, palmitic: 25, stearic: 34, ricinoleic: 0, oleic: 35, linoleic: 3, linolenic: 0 },
    iodine: 37,
    notes: "Great hard butter, but keep flexible oils in the recipe."
  },
  {
    name: "Mango Butter",
    category: "Butters",
    sapNaoh: 0.137,
    sapKoh: 0.192,
    color: "White to pale cream.",
    usage: "Often 5%–15%.",
    contributes: ["hardness", "creaminess", "conditioning", "silky feel"],
    qualities: { hardness: "medium", cleansing: "low", bubbly: "low", creamy: "high", conditioning: "high" },
    fattyAcids: { lauric: 0, myristic: 0, palmitic: 7, stearic: 42, ricinoleic: 0, oleic: 45, linoleic: 3, linolenic: 0 },
    iodine: 45,
    notes: "Feels a little lighter than shea while still adding creamy hardness."
  },
  {
    name: "Kokum Butter",
    category: "Butters",
    sapNaoh: 0.135,
    sapKoh: 0.190,
    color: "White to pale.",
    usage: "Often 3%–10%. Can make a very hard bar.",
    contributes: ["hardness", "longevity", "creaminess"],
    qualities: { hardness: "high", cleansing: "low", bubbly: "low", creamy: "high", conditioning: "medium" },
    fattyAcids: { lauric: 0, myristic: 0, palmitic: 4, stearic: 56, ricinoleic: 0, oleic: 36, linoleic: 2, linolenic: 0 },
    iodine: 35,
    notes: "Very firm butter; useful in small percentages."
  },
  {
    name: "Jojoba Oil",
    category: "Waxes",
    sapNaoh: 0.069,
    sapKoh: 0.097,
    color: "Golden yellow.",
    usage: "Usually 1%–5% because it is a liquid wax and expensive.",
    contributes: ["conditioning", "luxury label appeal", "softness"],
    qualities: { hardness: "low", cleansing: "low", bubbly: "low", creamy: "low", conditioning: "medium" },
    fattyAcids: { lauric: 0, myristic: 0, palmitic: 0, stearic: 0, ricinoleic: 0, oleic: 12, linoleic: 0, linolenic: 0 },
    iodine: 82,
    notes: "Acts differently from normal triglyceride oils; verify SAP and keep low."
  },
  {
    name: "Beeswax",
    category: "Waxes",
    sapNaoh: 0.067,
    sapKoh: 0.094,
    color: "White to yellow depending on refinement.",
    usage: "Usually 1%–3% in bar soap. Melts hot and can speed/thicken batter.",
    contributes: ["hardness", "longevity", "reduced lather if too high"],
    qualities: { hardness: "high", cleansing: "low", bubbly: "low", creamy: "low", conditioning: "low" },
    notes: "Use carefully; too much can suppress lather and create drag."
  },
  {
    name: "Stearic Acid",
    category: "Waxes",
    sapNaoh: 0.141,
    sapKoh: 0.198,
    color: "White flakes or powder.",
    usage: "Often 0.5%–3% in specialty bars. High use can seize CP batter.",
    contributes: ["hardness", "creaminess", "very fast trace"],
    qualities: { hardness: "very high", cleansing: "low", bubbly: "low", creamy: "very high", conditioning: "low" },
    fattyAcids: { lauric: 0, myristic: 0, palmitic: 0, stearic: 95, ricinoleic: 0, oleic: 0, linoleic: 0, linolenic: 0 },
    iodine: 2,
    notes: "Great for shave/creaminess formulas, but not beginner-friendly in CP."
  },
  { name: "White Kaolin Clay", aliases: ["Kaolin Clay"], category: "Clays", color: "White to off-white", usage: "Common at 0.5–2 tsp per lb oils or about 0.5%–2% of oils.", defaultRate: 1, base: "oils", contributes: ["slip", "silky feel", "mild exfoliation", "fragrance anchoring"], notes: "Gentle clay; useful for shaving bars and fragrance anchoring." },
  { name: "Pink Kaolin Clay", aliases: ["Rose Kaolin", "Pink Clay"], category: "Clays", color: "Soft pink to dusty rose", usage: "Common at about 0.5%–2% of oils; higher amounts deepen color and can feel more drying.", defaultRate: 1, base: "oils", contributes: ["pink color", "silky slip", "mild exfoliation", "fragrance anchoring"], notes: "Great for soft rose/pink color without mica." },
  { name: "French Green Clay", category: "Clays", color: "Green to olive", usage: "Often 0.5%–2% of oils. Use lighter for pale green.", defaultRate: 1, base: "oils", contributes: ["green color", "slip", "oil-absorbing feel", "mild exfoliation"], notes: "Can make bars feel more cleansing/dry if used heavily." },
  { name: "Bentonite Clay", category: "Clays", color: "Gray, cream, or greenish-gray", usage: "Often 0.5%–2% of oils. Disperse well to avoid clumps.", defaultRate: 1, base: "oils", contributes: ["slip", "shaving glide", "oil absorption", "thickening"], notes: "Popular for shaving soap, but it can thicken batter." },
  { name: "Rhassoul Clay", aliases: ["Moroccan Lava Clay"], category: "Clays", color: "Tan to reddish brown", usage: "Often 0.5%–2% of oils.", defaultRate: 1, base: "oils", contributes: ["earthy color", "slip", "mild exfoliation", "oil absorption"], notes: "Good for spa-style bars and natural color." },
  { name: "Red Moroccan Clay", category: "Clays", color: "Brick red to terracotta", usage: "Often 0.5%–2% of oils.", defaultRate: 1, base: "oils", contributes: ["red/terracotta color", "silky feel", "mild exfoliation"], notes: "Can create warm red-orange natural tones." },
  { name: "Brazilian Purple Clay", category: "Clays", color: "Lavender to muted purple", usage: "Often 0.5%–2% of oils.", defaultRate: 1, base: "oils", contributes: ["purple color", "silky feel", "mild exfoliation"], notes: "Natural purple shades may mute or shift depending on recipe." },
  { name: "Sea Clay", category: "Clays", color: "Green-gray", usage: "Often 0.5%–2% of oils.", defaultRate: 1, base: "oils", contributes: ["green-gray color", "slip", "oil-absorbing feel"], notes: "Nice for spa/ocean designs." },
  { name: "Activated Charcoal", category: "Colorants", color: "Black to charcoal gray", usage: "Often 0.25%–1.5% of oils, or about 1 tsp per lb oils. Too much can make gray lather.", defaultRate: 0.5, base: "oils", contributes: ["black color", "gray tones", "label appeal", "possible gray lather if high"], notes: "Disperse well in oil. Start small for clean-looking lather." },
  { name: "Titanium Dioxide", aliases: ["TD"], category: "Colorants", color: "White", usage: "Often 0.25%–1% of oils. Use oil- or water-dispersible type correctly.", defaultRate: 0.5, base: "oils", contributes: ["white color", "pastel color support", "can cause glycerin rivers if overheated"], notes: "Disperse thoroughly before adding." },
  { name: "Mica", aliases: ["Cosmetic Mica"], category: "Colorants", color: "Varies by pigment", usage: "Often 0.5–1 tsp per lb oils; check supplier for CP stability.", defaultRate: 1, base: "oils", contributes: ["bright color", "swirls", "sparkle on tops"], notes: "Use soap-stable cosmetic mica. Some colors morph in high pH." },
  { name: "Indigo Powder", category: "Colorants", color: "Blue to gray-blue", usage: "Start around 0.25%–1% of oils.", defaultRate: 0.5, base: "oils", contributes: ["blue/gray natural color", "botanical appeal"], notes: "Can be unpredictable; test small batches." },
  { name: "Alkanet Root Powder", category: "Colorants", color: "Purple, gray, or mauve depending on pH and infusion", usage: "Often infused into oils; start small.", defaultRate: 0.5, base: "oils", contributes: ["natural purple/mauve", "botanical appeal"], notes: "Color is famously moody. Test before selling." },
  { name: "Madder Root Powder", category: "Colorants", color: "Pink, peach, red, or mauve", usage: "Often infused or used around 0.25%–1% of oils.", defaultRate: 0.5, base: "oils", contributes: ["natural pink/red tones", "botanical appeal"], notes: "Shade depends heavily on recipe and method." },
  { name: "Annatto Seed", category: "Colorants", color: "Yellow to orange", usage: "Usually oil-infused; start lightly.", defaultRate: 0.25, base: "oils", contributes: ["yellow/orange natural color"], notes: "Strong colorant; too much can stain lather." },
  { name: "Turmeric Powder", category: "Colorants", color: "Yellow to orange", usage: "Start very low, around 0.1%–0.5% of oils.", defaultRate: 0.25, base: "oils", contributes: ["gold/yellow color", "speckles if not dispersed"], notes: "Can stain washcloths if too high." },
  { name: "Spirulina Powder", category: "Colorants", color: "Green; may fade or brown", usage: "Start around 0.25%–1% of oils.", defaultRate: 0.5, base: "oils", contributes: ["green color", "botanical look"], notes: "Natural green can fade over time." },
  { name: "Cocoa Powder", category: "Colorants", color: "Brown", usage: "Often 0.5%–2% of oils.", defaultRate: 1, base: "oils", contributes: ["brown color", "speckles", "chocolate look"], notes: "Can scent lightly but do not rely on it as fragrance." },
  { name: "Sugar", aliases: ["White Sugar", "Granulated Sugar"], category: "Additives", color: "No major color at low use", usage: "Often 0.5%–2% of oils, commonly dissolved in water before lye or added to cooled lye water.", defaultRate: 1, base: "oils", contributes: ["bubbly lather boost", "can increase heat", "can discolor if overheated"], notes: "Dissolve fully. Sugars can make soap heat up faster." },
  { name: "Fine Sea Salt", aliases: ["Salt", "Sodium Chloride"], category: "Additives", color: "White; may create opaque/white effects", usage: "For normal bars often 0.5%–3% of oils for hardness. Salt bars can be 50%–100% of oils but need special formulation.", defaultRate: 1, base: "oils", contributes: ["hardness", "reduced lather if high", "spa feel"], notes: "Avoid Epsom salt in CP unless you know the behavior; it can create weeping/odd texture." },
  { name: "Sodium Lactate", category: "Additives", color: "Clear liquid", usage: "Often 1%–3% of oil weight, added to cooled lye solution.", defaultRate: 2, base: "oils", contributes: ["hardness", "easier unmolding", "smoother HP texture"], notes: "Too much can make soap brittle or crumbly." },
  { name: "Honey", category: "Additives", color: "Golden; can darken soap", usage: "Often 0.5%–3% of oils. Mix well and watch heat.", defaultRate: 1, base: "oils", contributes: ["lather boost", "label appeal", "extra heat", "tan/brown color"], notes: "Honey can overheat, crack, or volcano if pushed too hot." },
  { name: "Vegetable Glycerin", aliases: ["Glycerin"], category: "Additives", color: "Clear", usage: "Often 0.5%–3% in specialty formulas.", defaultRate: 1, base: "oils", contributes: ["humectant feel", "solvent for colorants", "can make bars softer if high"], notes: "Soap already naturally creates glycerin; added glycerin is optional." },
  { name: "Citric Acid", category: "Additives", color: "White powder", usage: "Often 1%–3% of oils for chelation, but extra NaOH is needed because citric acid consumes lye.", defaultRate: 2, base: "oils", contributes: ["chelating support", "reduced soap scum", "requires lye adjustment"], notes: "Advanced: add roughly 0.624 g extra NaOH per 1 g citric acid for NaOH soap. Verify before use." },
  { name: "Sodium Citrate", category: "Additives", color: "White powder", usage: "Often around 1%–3% of oils as a chelator.", defaultRate: 2, base: "oils", contributes: ["chelating support", "reduced soap scum", "hard-water helper"], notes: "Easier than citric acid because it does not require the same lye neutralization math." },
  { name: "Colloidal Oatmeal", aliases: ["Oats", "Oatmeal"], category: "Botanicals", color: "Cream/tan speckles", usage: "Often 0.5%–3% of oils.", defaultRate: 1, base: "oils", contributes: ["soothing label appeal", "silky feel", "gentle exfoliation"], notes: "Fine grind is gentler. Whole oats can feel scratchy." },
  { name: "Coffee Grounds", category: "Exfoliants", color: "Brown/black speckles", usage: "Often 0.25%–1% of oils. Use finely ground and not too much.", defaultRate: 0.5, base: "oils", contributes: ["scrubby exfoliation", "speckles", "coffee look"], notes: "Can be very scratchy. Use restraint." },
  { name: "Pumice Powder", category: "Exfoliants", color: "Gray/off-white", usage: "Often 0.5%–2% for mechanic/garden bars.", defaultRate: 1, base: "oils", contributes: ["strong exfoliation", "scrub bar"], notes: "Too harsh for face or sensitive skin bars." },
  { name: "Poppy Seeds", category: "Exfoliants", color: "Black/blue speckles", usage: "Often 0.25%–1% of oils.", defaultRate: 0.5, base: "oils", contributes: ["decorative speckles", "scrub"], notes: "Can feel scratchy if overused." },
  { name: "Lavender Buds", category: "Botanicals", color: "Purple before cure; often browns in soap", usage: "Best on tops only; use lightly.", defaultRate: 0.25, base: "oils", contributes: ["decorative top", "botanical look"], notes: "Most botanicals turn brown inside CP soap. Tops may still brown over time." },
  { name: "Calendula Petals", category: "Botanicals", color: "Yellow/orange; one of the better petals for staying pretty", usage: "Use lightly on tops or infused in oil.", defaultRate: 0.25, base: "oils", contributes: ["decorative top", "yellow/orange flecks", "infusion appeal"], notes: "One of the safer-looking botanicals for CP soap decoration." },
  { name: "Rose Petals", category: "Botanicals", color: "Usually brown in CP soap", usage: "Best used lightly on tops, not mixed throughout.", defaultRate: 0.25, base: "oils", contributes: ["romantic label appeal", "decorative top"], notes: "Rose petals commonly brown in soap." },
  { name: "Orange Peel Powder", category: "Botanicals", color: "Orange/yellow speckles", usage: "Often 0.25%–1% of oils.", defaultRate: 0.5, base: "oils", contributes: ["speckles", "light exfoliation", "citrus look"], notes: "Does not replace fragrance or essential oil." },
  { name: "Goat Milk", category: "Liquids", color: "Cream to tan; can darken if overheated", usage: "Can replace part or all water. Freeze/slush before lye for lighter color.", defaultRate: 100, base: "water", contributes: ["creaminess", "label appeal", "extra sugars", "heat/discoloration risk"], notes: "Add lye slowly to frozen/slushy milk and keep temperatures controlled." },
  { name: "Coconut Milk", category: "Liquids", color: "Cream; may darken slightly", usage: "Can replace part or all water, or be added to oils as part of liquid plan.", defaultRate: 100, base: "water", contributes: ["creaminess", "extra sugars/fats", "label appeal"], notes: "Account for total liquid. Watch overheating." },
  { name: "Aloe Vera Juice", category: "Liquids", color: "Clear to pale", usage: "Can replace part or all water in many recipes.", defaultRate: 100, base: "water", contributes: ["label appeal", "fluid replacement", "mildness perception"], notes: "Use plain aloe juice without sugar/alcohol additives when possible." },
  { name: "Beer", category: "Liquids", color: "Tan to brown; depends on beer", usage: "Can replace water after boiling/flattening and chilling/freezing. Advanced beginner caution.", defaultRate: 100, base: "water", contributes: ["sugar lather boost", "label appeal", "heat risk", "odor during lye mixing"], notes: "Remove carbonation and alcohol first. Add lye slowly." },
  { name: "Tussah Silk", aliases: ["Silk"], category: "Additives", color: "No major color at tiny use", usage: "Tiny pinch dissolved in hot lye water.", defaultRate: 0.05, base: "oils", contributes: ["silky feel", "label appeal"], notes: "Not vegan. Needs strong hot lye solution to dissolve." }
];

const propertyGuide = [
  { term: "Hardness", meaning: "How firm the bar is after unmolding and curing. Usually driven by saturated fatty acids like lauric, myristic, palmitic, and stearic.", practical: "Higher hardness can mean a longer-lasting bar, but too high can become brittle or waxy." },
  { term: "Cleansing", meaning: "How strongly the soap removes oil from skin. Usually driven by lauric and myristic acids, common in coconut, palm kernel, and babassu.", practical: "Higher cleansing can make big bubbles, but can feel drying if not balanced with superfat and conditioning oils." },
  { term: "Conditioning", meaning: "A clue for mild, skin-feeling qualities. Often associated with oleic, linoleic, linolenic, and ricinoleic acids.", practical: "High conditioning can feel lovely, but too many soft/high-iodine oils may create a softer bar or shorter shelf life." },
  { term: "Bubbly Lather", meaning: "Big, fluffy, quick-forming bubbles. Usually comes from lauric, myristic, and ricinoleic acids.", practical: "Coconut-type oils and castor oil help, but too much high-cleansing oil can be drying." },
  { term: "Creamy Lather", meaning: "Dense, lotion-like, stable lather. Usually supported by palmitic, stearic, and ricinoleic acids.", practical: "Butters, lard, tallow, palm, and castor can improve creamy lather." },
  { term: "Lauric Acid", meaning: "A saturated fatty acid that adds hardness, cleansing, and large bubbles.", practical: "Found heavily in coconut, palm kernel, and babassu. Great for lather, but can feel stripping when too high." },
  { term: "Myristic Acid", meaning: "A saturated fatty acid that adds hardness, cleansing, and bubbly lather.", practical: "Often travels with lauric acid in coconut-like oils." },
  { term: "Palmitic Acid", meaning: "A saturated fatty acid that adds hardness, longevity, and creamy/stable lather.", practical: "Found in palm, lard, tallow, cocoa butter, rice bran, and other oils." },
  { term: "Stearic Acid", meaning: "A saturated fatty acid that adds hardness, longevity, and creamy lather.", practical: "High stearic ingredients can thicken or accelerate trace, especially stearic acid itself." },
  { term: "Ricinoleic Acid", meaning: "The signature fatty acid in castor oil that helps lather form and stay stable.", practical: "A little castor is helpful. Too much can make bars sticky or soft." },
  { term: "Oleic Acid", meaning: "A monounsaturated fatty acid that contributes mildness and conditioning.", practical: "High in olive, avocado, high oleic sunflower, sweet almond, and similar oils. High-oleic soaps often need longer cure." },
  { term: "Linoleic Acid", meaning: "A polyunsaturated fatty acid associated with conditioning and a lighter skin feel.", practical: "High amounts can increase oxidation/DOS risk, so high-linoleic oils are often used modestly." },
  { term: "Linolenic Acid", meaning: "A highly unsaturated fatty acid associated with conditioning, but it oxidizes more easily.", practical: "Keep high-linolenic oils lower unless you have a specific reason and good freshness control." },
  { term: "Iodine", meaning: "A number that estimates unsaturation. Higher iodine usually means softer, more conditioning, and more oxidation-prone oils.", practical: "A very high iodine recipe may need a longer cure and careful shelf-life planning." },
  { term: "INS", meaning: "An old soapmaking index that tries to summarize hardness/solubility behavior into one number.", practical: "Use it as a clue, not a law. Real soap performance depends on the full formula, cure, water, additives, and process." },
  { term: "SAP Value", meaning: "The amount of lye needed to saponify a specific fat. NaOH SAP is for bar soap; KOH SAP is for liquid soap.", practical: "Always recalculate when swapping oils. Supplier SAP values can vary by batch and source." },
  { term: "Superfat", meaning: "The intentional lye discount or extra unsaponified oil left in the finished soap.", practical: "Common CP ranges are around 3%–8%, but recipe purpose matters." },
  { term: "Water : Lye Ratio", meaning: "How much water is used compared with NaOH. A 2.4:1 ratio means 2.4 parts water for every 1 part NaOH.", practical: "More water can slow trace but may need longer unmolding/cure. Less water can move faster." },
  { term: "Lye Concentration", meaning: "The percent of the lye solution that is NaOH. Higher concentration means less water.", practical: "30%–33% is common for many CP designs, but milk/salt/specialty recipes may need different handling." }
];

const oilLibrary = ingredientLibrary
  .filter(item => Number.isFinite(item.sapNaoh))
  .map(item => ({ name: item.name, sap: item.sapNaoh, custom: false }))
  .concat([{ name: "Custom oil / butter", sap: 0.134, custom: true }]);

const additiveLibrary = ingredientLibrary
  .filter(item => !Number.isFinite(item.sapNaoh) || ["Clays", "Colorants", "Additives", "Botanicals", "Exfoliants", "Liquids"].includes(item.category));

const starterRows = [
  { name: "Olive Oil", percent: 40, weight: 380, sap: 0.134 },
  { name: "Coconut Oil 76°", percent: 25, weight: 237.5, sap: 0.183 },
  { name: "Shea Butter", percent: 15, weight: 142.5, sap: 0.128 },
  { name: "Sweet Almond Oil", percent: 10, weight: 95, sap: 0.136 },
  { name: "Castor Oil", percent: 10, weight: 95, sap: 0.128 }
];

const els = {
  recipeForm: document.querySelector("#recipeForm"),
  oilRows: document.querySelector("#oilRows"),
  oilTemplate: document.querySelector("#oilRowTemplate"),
  recipeName: document.querySelector("#recipeName"),
  unitSelect: document.querySelector("#unitSelect"),
  superfat: document.querySelector("#superfat"),
  waterMethod: document.querySelector("#waterMethod"),
  waterRatio: document.querySelector("#waterRatio"),
  lyeConcentration: document.querySelector("#lyeConcentration"),
  waterPercent: document.querySelector("#waterPercent"),
  ratioField: document.querySelector("#ratioField"),
  concentrationField: document.querySelector("#concentrationField"),
  percentField: document.querySelector("#percentField"),
  waterBadge: document.querySelector("#waterBadge"),
  fragranceLoad: document.querySelector("#fragranceLoad"),
  fragranceName: document.querySelector("#fragranceName"),
  additiveSelect: document.querySelector("#additiveSelect"),
  additiveRate: document.querySelector("#additiveRate"),
  additiveBase: document.querySelector("#additiveBase"),
  additiveAmount: document.querySelector("#additiveAmount"),
  additiveProperties: document.querySelector("#additiveProperties"),
  batchNotes: document.querySelector("#batchNotes"),
  totalPercent: document.querySelector("#totalPercent"),
  totalOilInputWeight: document.querySelector("#totalOilInputWeight"),
  weightHeading: document.querySelector(".weight-heading"),
  resultRecipeName: document.querySelector("#resultRecipeName"),
  totalOils: document.querySelector("#totalOils"),
  lyeBefore: document.querySelector("#lyeBefore"),
  lyeNeeded: document.querySelector("#lyeNeeded"),
  waterNeeded: document.querySelector("#waterNeeded"),
  fragranceNeeded: document.querySelector("#fragranceNeeded"),
  batterWeight: document.querySelector("#batterWeight"),
  miniDetails: document.querySelector("#miniDetails"),
  qualityPanel: document.querySelector("#qualityPanel"),
  warnings: document.querySelector("#warnings"),
  previewContent: document.querySelector("#previewContent"),
  recipePreview: document.querySelector("#recipePreview"),
  savedRecipes: document.querySelector("#savedRecipes"),
  addOil: document.querySelector("#addOil"),
  balanceOils: document.querySelector("#balanceOils"),
  saveRecipe: document.querySelector("#saveRecipe"),
  printRecipe: document.querySelector("#printRecipe"),
  resetRecipe: document.querySelector("#resetRecipe"),
  ingredientSearch: document.querySelector("#ingredientSearch"),
  ingredientCategoryFilter: document.querySelector("#ingredientCategoryFilter"),
  ingredientCards: document.querySelector("#ingredientCards"),
  ingredientDetail: document.querySelector("#ingredientDetail"),
  printIngredientLibrary: document.querySelector("#printIngredientLibrary"),
  propertiesGuide: document.querySelector("#propertiesGuide"),
  printPropertiesGuide: document.querySelector("#printPropertiesGuide"),
  mobileMenuButton: document.querySelector(".mobile-menu-button"),
  navLinks: document.querySelector("#navLinks")
};

let savedRecipes = loadSavedRecipes();
let lastCalculation = null;

function decimal(value, places = 2) {
  const num = Number(value);
  if (!Number.isFinite(num)) return 0;
  return Number(num.toFixed(places));
}

function formatNumber(value, places = 2) {
  const num = Number(value);
  if (!Number.isFinite(num)) return "0";
  return num.toLocaleString(undefined, {
    minimumFractionDigits: places,
    maximumFractionDigits: places
  });
}

function formatWeight(value, unit, places = 2) {
  return `${formatNumber(value, places)} ${unit}`;
}

function converted(value, unit) {
  if (unit === "g") return `${formatWeight(value / 28.3495, "oz", 2)}`;
  return `${formatWeight(value * 28.3495, "g", 1)}`;
}

function normalize(value) {
  return String(value || "").toLowerCase().normalize("NFKD").replace(/[\u0300-\u036f]/g, "");
}

function escapeHtml(value) {
  return String(value ?? "")
    .replaceAll("&", "&amp;")
    .replaceAll("<", "&lt;")
    .replaceAll(">", "&gt;")
    .replaceAll('"', "&quot;")
    .replaceAll("'", "&#039;");
}

function getIngredientByName(name) {
  const exact = ingredientLibrary.find(item => item.name === name);
  if (exact) return exact;
  const n = normalize(name);
  return ingredientLibrary.find(item => normalize(item.name) === n || (item.aliases || []).some(alias => normalize(alias) === n));
}

function getOilByName(name) {
  return oilLibrary.find(oil => oil.name === name) || oilLibrary[0];
}

function propertyChips(item) {
  const chips = item.contributes || [];
  return chips.slice(0, 7).map(chip => `<span>${escapeHtml(chip)}</span>`).join("");
}

function ingredientDetailMarkup(item, compact = false) {
  if (!item) return "";
  const sapMarkup = Number.isFinite(item.sapNaoh)
    ? `<p><strong>NaOH SAP:</strong> ${formatNumber(item.sapNaoh, 3)}${Number.isFinite(item.sapKoh) ? ` · <strong>KOH SAP:</strong> ${formatNumber(item.sapKoh, 3)}` : ""}</p>`
    : "";
  const fattyMarkup = item.fattyAcids && !compact
    ? `<div class="fatty-mini-grid">${Object.entries(item.fattyAcids).map(([key, val]) => `<span><strong>${labelFattyAcid(key)}</strong>${formatNumber(val, 0)}%</span>`).join("")}</div>`
    : "";
  return `
    <div class="ingredient-detail-content">
      <p class="eyebrow">${escapeHtml(item.category || "Ingredient")}</p>
      <h3>${escapeHtml(item.name)}</h3>
      <p><strong>Color:</strong> ${escapeHtml(item.color || "Varies by supplier and recipe.")}</p>
      ${sapMarkup}
      <p><strong>Typical use:</strong> ${escapeHtml(item.usage || "Usage depends on recipe and supplier guidance.")}</p>
      <div class="chip-row">${propertyChips(item)}</div>
      <p><strong>Notes:</strong> ${escapeHtml(item.notes || "Test in a small batch and document results.")}</p>
      ${fattyMarkup}
    </div>
  `;
}

function labelFattyAcid(key) {
  const labels = {
    lauric: "Lauric", myristic: "Myristic", palmitic: "Palmitic", stearic: "Stearic",
    ricinoleic: "Ricinoleic", oleic: "Oleic", linoleic: "Linoleic", linolenic: "Linolenic"
  };
  return labels[key] || key;
}

function populateOilSelect(select, selectedName) {
  select.innerHTML = "";
  const grouped = oilLibrary.reduce((acc, oil) => {
    const item = getIngredientByName(oil.name);
    const group = oil.custom ? "Custom" : item?.category || "Oils";
    (acc[group] ||= []).push(oil);
    return acc;
  }, {});

  Object.entries(grouped).forEach(([groupName, oils]) => {
    const optgroup = document.createElement("optgroup");
    optgroup.label = groupName;
    oils.forEach(oil => {
      const option = document.createElement("option");
      option.value = oil.name;
      option.textContent = oil.name;
      const ingredient = getIngredientByName(oil.name);
      if (ingredient) option.title = `${ingredient.color || ""} ${ingredient.contributes ? ingredient.contributes.join(", ") : ""}`.trim();
      optgroup.appendChild(option);
    });
    select.appendChild(optgroup);
  });
  select.value = selectedName || oilLibrary[0].name;
}

function updateRowPopover(row) {
  const select = row.querySelector(".oil-select");
  const popover = row.querySelector(".ingredient-popover");
  const infoButton = row.querySelector(".ingredient-info-button");
  const ingredient = getIngredientByName(select.value);
  if (!ingredient) {
    popover.innerHTML = `<p><strong>Custom oil/butter:</strong> Enter a verified NaOH SAP value before making soap.</p>`;
    infoButton.title = "Custom oil/butter: enter a verified SAP value.";
    return;
  }
  popover.innerHTML = ingredientDetailMarkup(ingredient, true);
  infoButton.title = `${ingredient.name}: ${ingredient.contributes ? ingredient.contributes.join(", ") : ingredient.category}`;
}

function addOilRow(rowData = {}) {
  const clone = els.oilTemplate.content.cloneNode(true);
  const row = clone.querySelector("tr");
  const select = clone.querySelector(".oil-select");
  const customInput = clone.querySelector(".custom-oil");
  const percentInput = clone.querySelector(".oil-percent-input");
  const weightInput = clone.querySelector(".oil-weight");
  const sapInput = clone.querySelector(".oil-sap");
  const removeButton = clone.querySelector(".remove-oil");
  const infoButton = clone.querySelector(".ingredient-info-button");

  populateOilSelect(select, rowData.name || oilLibrary[0].name);
  percentInput.value = rowData.percent ?? 0;
  weightInput.value = rowData.weight ?? 0;
  sapInput.value = rowData.sap ?? getOilByName(select.value).sap;

  if (rowData.customName) {
    select.value = "Custom oil / butter";
    customInput.classList.remove("is-hidden");
    customInput.value = rowData.customName;
  }

  updateRowPopover(row);

  select.addEventListener("change", () => {
    const selectedOil = getOilByName(select.value);
    if (selectedOil.custom) {
      customInput.classList.remove("is-hidden");
      customInput.focus();
    } else {
      customInput.classList.add("is-hidden");
      customInput.value = "";
      sapInput.value = selectedOil.sap;
    }
    updateRowPopover(row);
    calculateAndRender();
  });

  infoButton.addEventListener("click", event => {
    event.stopPropagation();
    row.classList.toggle("popover-open");
  });

  document.addEventListener("click", event => {
    if (!row.contains(event.target)) row.classList.remove("popover-open");
  });

  [customInput, percentInput, weightInput, sapInput].forEach(input => {
    input.addEventListener("input", calculateAndRender);
    input.addEventListener("change", calculateAndRender);
  });

  removeButton.addEventListener("click", () => {
    const rows = els.oilRows.querySelectorAll("tr");
    if (rows.length <= 1) {
      showTemporaryWarning("A recipe needs at least one oil or butter row.");
      return;
    }
    row.remove();
    calculateAndRender();
  });

  els.oilRows.appendChild(clone);
  calculateAndRender();
}

function getRows() {
  return [...els.oilRows.querySelectorAll("tr")].map(row => {
    const select = row.querySelector(".oil-select");
    const customInput = row.querySelector(".custom-oil");
    const selectedOil = getOilByName(select.value);
    const customName = !customInput.classList.contains("is-hidden") ? customInput.value.trim() : "";
    return {
      name: selectedOil.custom ? (customName || "Custom oil / butter") : selectedOil.name,
      selectName: selectedOil.name,
      customName,
      percent: Number(row.querySelector(".oil-percent-input").value) || 0,
      weight: Number(row.querySelector(".oil-weight").value) || 0,
      sap: Number(row.querySelector(".oil-sap").value) || 0
    };
  });
}

function setRows(rows) {
  els.oilRows.innerHTML = "";
  rows.forEach(row => addOilRow(row));
  calculateAndRender();
}

function getSettings() {
  return {
    recipeName: els.recipeName.value.trim() || "Untitled Soap Recipe",
    unit: els.unitSelect.value,
    superfat: Number(els.superfat.value) || 0,
    waterMethod: els.waterMethod.value,
    waterRatio: Number(els.waterRatio.value) || 0,
    lyeConcentration: Number(els.lyeConcentration.value) || 0,
    waterPercent: Number(els.waterPercent.value) || 0,
    fragranceLoad: Number(els.fragranceLoad.value) || 0,
    fragranceName: els.fragranceName.value.trim(),
    additiveName: els.additiveSelect?.value || "Sugar",
    additiveRate: Number(els.additiveRate?.value) || 0,
    additiveBase: els.additiveBase?.value || "oils",
    batchNotes: els.batchNotes.value.trim()
  };
}

function calculateRecipe() {
  const settings = getSettings();
  const rows = getRows();
  const totalOils = rows.reduce((sum, row) => sum + row.weight, 0);
  const totalPercent = rows.reduce((sum, row) => sum + row.percent, 0);
  const lyeBeforeSuperfat = rows.reduce((sum, row) => sum + row.weight * row.sap, 0);
  const lyeAfterSuperfat = lyeBeforeSuperfat * (1 - settings.superfat / 100);

  let water = 0;
  let lyeConcentration = 0;
  let waterRatio = 0;
  let waterAsPercent = 0;

  if (settings.waterMethod === "ratio") {
    water = lyeAfterSuperfat * settings.waterRatio;
    waterRatio = settings.waterRatio;
    lyeConcentration = lyeAfterSuperfat + water > 0 ? (lyeAfterSuperfat / (lyeAfterSuperfat + water)) * 100 : 0;
    waterAsPercent = totalOils > 0 ? (water / totalOils) * 100 : 0;
  }

  if (settings.waterMethod === "concentration") {
    water = settings.lyeConcentration > 0 ? lyeAfterSuperfat * ((100 - settings.lyeConcentration) / settings.lyeConcentration) : 0;
    lyeConcentration = settings.lyeConcentration;
    waterRatio = lyeAfterSuperfat > 0 ? water / lyeAfterSuperfat : 0;
    waterAsPercent = totalOils > 0 ? (water / totalOils) * 100 : 0;
  }

  if (settings.waterMethod === "percent") {
    water = totalOils * (settings.waterPercent / 100);
    waterAsPercent = settings.waterPercent;
    waterRatio = lyeAfterSuperfat > 0 ? water / lyeAfterSuperfat : 0;
    lyeConcentration = lyeAfterSuperfat + water > 0 ? (lyeAfterSuperfat / (lyeAfterSuperfat + water)) * 100 : 0;
  }

  const fragrance = totalOils * (settings.fragranceLoad / 100);
  const batterWeight = totalOils + lyeAfterSuperfat + water + fragrance;
  const additiveBaseWeight = settings.additiveBase === "water" ? water : settings.additiveBase === "batter" ? batterWeight : totalOils;
  const additiveAmount = additiveBaseWeight * (settings.additiveRate / 100);
  const qualityProfile = calculateQualityProfile(rows, totalOils);

  const warnings = [];
  if (totalOils <= 0) warnings.push("Add oil weights before making a batch.");
  if (Math.abs(totalPercent - 100) > 0.2) warnings.push(`Oil percentages currently total ${formatNumber(totalPercent, 1)}%. Use Balance Oils or adjust to 100%.`);
  if (settings.superfat < 0 || settings.superfat > 20) warnings.push("Superfat should usually stay between 0% and 20%.");
  if (settings.fragranceLoad > 6) warnings.push("Fragrance load is above 6%. Check the fragrance supplier and IFRA limit before using it.");
  if (lyeConcentration > 0 && (lyeConcentration < 25 || lyeConcentration > 45)) warnings.push(`Lye concentration is ${formatNumber(lyeConcentration, 1)}%. Many cold process recipes stay around 25%–40%.`);
  if (waterRatio > 0 && (waterRatio < 1.2 || waterRatio > 3.5)) warnings.push(`Water:lye ratio is ${formatNumber(waterRatio, 2)}:1. Double-check that setting.`);
  if (rows.some(row => row.sap <= 0)) warnings.push("One or more SAP values are missing. Every oil/butter needs a NaOH SAP value.");
  if (rows.some(row => row.weight < 0 || row.percent < 0)) warnings.push("Negative oil weights or percentages are not valid.");
  if (qualityProfile.coverage < 70 && totalOils > 0) warnings.push("Soap quality profile is estimated from ingredients with stored fatty-acid data. Custom oils may not be included.");
  if (settings.additiveName === "Citric Acid" && settings.additiveRate > 0) warnings.push("Citric acid consumes lye. Add the required extra NaOH or use sodium citrate instead.");

  return {
    settings,
    rows,
    totalOils,
    totalPercent,
    lyeBeforeSuperfat,
    lyeAfterSuperfat,
    water,
    fragrance,
    batterWeight,
    additiveAmount,
    additiveBaseWeight,
    qualityProfile,
    lyeConcentration,
    waterRatio,
    waterAsPercent,
    warnings,
    createdAt: new Date().toISOString()
  };
}

function calculateQualityProfile(rows, totalOils) {
  const keys = ["lauric", "myristic", "palmitic", "stearic", "ricinoleic", "oleic", "linoleic", "linolenic"];
  const fatty = Object.fromEntries(keys.map(key => [key, 0]));
  let coveredWeight = 0;
  let iodine = 0;
  let iodineWeight = 0;

  rows.forEach(row => {
    const ingredient = getIngredientByName(row.selectName || row.name);
    if (!ingredient || !ingredient.fattyAcids || row.weight <= 0) return;
    coveredWeight += row.weight;
    keys.forEach(key => {
      fatty[key] += (ingredient.fattyAcids[key] || 0) * row.weight;
    });
    if (Number.isFinite(ingredient.iodine)) {
      iodine += ingredient.iodine * row.weight;
      iodineWeight += row.weight;
    }
  });

  if (coveredWeight > 0) {
    keys.forEach(key => { fatty[key] = fatty[key] / coveredWeight; });
  }

  const hardness = fatty.lauric + fatty.myristic + fatty.palmitic + fatty.stearic;
  const cleansing = fatty.lauric + fatty.myristic;
  const conditioning = fatty.oleic + fatty.linoleic + fatty.linolenic + fatty.ricinoleic;
  const bubbly = fatty.lauric + fatty.myristic + fatty.ricinoleic;
  const creamy = fatty.palmitic + fatty.stearic + fatty.ricinoleic;
  const iodineAvg = iodineWeight > 0 ? iodine / iodineWeight : 0;
  const ins = iodineAvg > 0 ? hardness * 2.2 - iodineAvg * 0.35 + 100 : 0;

  return {
    fatty,
    hardness,
    cleansing,
    conditioning,
    bubbly,
    creamy,
    iodine: iodineAvg,
    ins,
    coverage: totalOils > 0 ? (coveredWeight / totalOils) * 100 : 0
  };
}

function updateWaterUI() {
  const method = els.waterMethod.value;
  els.ratioField.classList.toggle("is-hidden", method !== "ratio");
  els.concentrationField.classList.toggle("is-hidden", method !== "concentration");
  els.percentField.classList.toggle("is-hidden", method !== "percent");
  els.waterBadge.textContent = method === "ratio" ? "Ratio" : method === "concentration" ? "Concentration" : "% of oils";
}

function renderCalculation(calc) {
  const unit = calc.settings.unit;
  const oppositeUnit = unit === "g" ? "oz" : "g";
  const places = unit === "g" ? 1 : 2;
  els.resultRecipeName.textContent = calc.settings.recipeName;
  els.totalOils.textContent = formatWeight(calc.totalOils, unit, places);
  els.lyeBefore.textContent = formatWeight(calc.lyeBeforeSuperfat, unit, places);
  els.lyeNeeded.textContent = formatWeight(calc.lyeAfterSuperfat, unit, places);
  els.waterNeeded.textContent = formatWeight(calc.water, unit, places);
  els.fragranceNeeded.textContent = formatWeight(calc.fragrance, unit, places);
  els.batterWeight.textContent = formatWeight(calc.batterWeight, unit, places);

  els.totalPercent.textContent = `${formatNumber(calc.totalPercent, 1)}%`;
  els.totalOilInputWeight.textContent = `${formatWeight(calc.totalOils, unit, places)}`;
  els.weightHeading.textContent = unit === "g" ? "Grams" : "Ounces";

  els.miniDetails.innerHTML = [
    `Superfat: ${formatNumber(calc.settings.superfat, 1)}%`,
    `Lye concentration: ${formatNumber(calc.lyeConcentration, 1)}%`,
    `Water:lye ratio: ${formatNumber(calc.waterRatio, 2)}:1`,
    `Water as oils: ${formatNumber(calc.waterAsPercent, 1)}%`,
    `${oppositeUnit.toUpperCase()} equivalents included in print`
  ].map(item => `<span>${item}</span>`).join("");

  renderQualityPanel(calc.qualityProfile);
  renderAdditiveResult(calc);

  if (calc.warnings.length) {
    els.warnings.hidden = false;
    els.warnings.innerHTML = calc.warnings.map(warning => `<p>${escapeHtml(warning)}</p>`).join("");
  } else {
    els.warnings.hidden = true;
    els.warnings.innerHTML = "";
  }

  renderPreview(calc);
}

function qualityStatus(value, type) {
  const ranges = {
    hardness: [29, 54], cleansing: [12, 22], conditioning: [44, 69], bubbly: [14, 46], creamy: [16, 48], iodine: [41, 70], ins: [136, 165]
  };
  const [low, high] = ranges[type] || [0, 999];
  if (!value) return "unknown";
  if (value < low) return "low";
  if (value > high) return "high";
  return "balanced";
}

function renderQualityPanel(profile) {
  if (!els.qualityPanel) return;
  const rows = [
    ["Hardness", profile.hardness, "hardness"],
    ["Cleansing", profile.cleansing, "cleansing"],
    ["Conditioning", profile.conditioning, "conditioning"],
    ["Bubbly", profile.bubbly, "bubbly"],
    ["Creamy", profile.creamy, "creamy"],
    ["Iodine", profile.iodine, "iodine"],
    ["INS", profile.ins, "ins"]
  ];
  const fattyRows = Object.entries(profile.fatty)
    .filter(([, value]) => value > 0.25)
    .map(([key, value]) => `<span><strong>${labelFattyAcid(key)}</strong>${formatNumber(value, 0)}%</span>`)
    .join("");

  els.qualityPanel.innerHTML = `
    <div class="quality-header">
      <div>
        <p class="eyebrow">Estimated soap properties</p>
        <h3>Recipe profile</h3>
      </div>
      <span>${formatNumber(profile.coverage, 0)}% data coverage</span>
    </div>
    <div class="quality-grid">
      ${rows.map(([label, value, type]) => `<div class="quality-pill ${qualityStatus(value, type)}"><span>${label}</span><strong>${formatNumber(value, 0)}</strong></div>`).join("")}
    </div>
    <div class="fatty-mini-grid">${fattyRows || "<span>Fatty acid data appears after recipe oils are selected.</span>"}</div>
  `;
}

function renderAdditiveResult(calc) {
  if (!els.additiveAmount) return;
  const unit = calc.settings.unit;
  const places = unit === "g" ? 1 : 2;
  const item = getIngredientByName(calc.settings.additiveName);
  els.additiveAmount.textContent = `${formatWeight(calc.additiveAmount, unit, places)} (${converted(calc.additiveAmount, unit)})`;
  if (item) {
    els.additiveProperties.innerHTML = `<strong>${escapeHtml(item.name)}:</strong> ${escapeHtml(item.color || "Color varies.")} · ${escapeHtml(item.usage || "Use depends on formula.")} ${item.contributes?.length ? `<span class="inline-note">Adds: ${escapeHtml(item.contributes.join(", "))}.</span>` : ""}`;
  }
}

function renderPreview(calc) {
  const unit = calc.settings.unit;
  const places = unit === "g" ? 1 : 2;
  els.recipePreview.querySelector("h3").textContent = calc.settings.recipeName;
  const oilsMarkup = calc.rows.map(row => `
    <tr>
      <td>${escapeHtml(row.name)}</td>
      <td>${formatNumber(row.percent, 1)}%</td>
      <td>${formatWeight(row.weight, unit, places)}</td>
    </tr>
  `).join("");

  const notesMarkup = calc.settings.batchNotes
    ? `<p><strong>Notes:</strong> ${escapeHtml(calc.settings.batchNotes)}</p>`
    : "";

  const additive = getIngredientByName(calc.settings.additiveName);
  const additiveMarkup = calc.settings.additiveRate > 0 ? `<span><strong>Additive helper:</strong> ${escapeHtml(calc.settings.additiveName)} — ${formatWeight(calc.additiveAmount, unit, places)} at ${formatNumber(calc.settings.additiveRate, 1)}% of ${calc.settings.additiveBase}${additive?.notes ? ` (${escapeHtml(additive.notes)})` : ""}</span>` : "";

  els.previewContent.innerHTML = `
    <div class="preview-meta">
      <span><strong>Total oils:</strong> ${formatWeight(calc.totalOils, unit, places)} (${converted(calc.totalOils, unit)})</span>
      <span><strong>Superfat:</strong> ${formatNumber(calc.settings.superfat, 1)}%</span>
      <span><strong>NaOH needed:</strong> ${formatWeight(calc.lyeAfterSuperfat, unit, places)} (${converted(calc.lyeAfterSuperfat, unit)})</span>
      <span><strong>Water needed:</strong> ${formatWeight(calc.water, unit, places)} (${converted(calc.water, unit)})</span>
      <span><strong>Fragrance:</strong> ${calc.settings.fragranceName ? `${escapeHtml(calc.settings.fragranceName)} — ` : ""}${formatWeight(calc.fragrance, unit, places)} (${formatNumber(calc.settings.fragranceLoad, 1)}%)</span>
      ${additiveMarkup}
    </div>
    <table class="preview-table">
      <thead><tr><th>Oil / Butter</th><th>%</th><th>${unit === "g" ? "Grams" : "Ounces"}</th></tr></thead>
      <tbody>${oilsMarkup}</tbody>
    </table>
    <div class="preview-meta">
      <span><strong>Lye concentration:</strong> ${formatNumber(calc.lyeConcentration, 1)}%</span>
      <span><strong>Water:lye ratio:</strong> ${formatNumber(calc.waterRatio, 2)}:1</span>
      <span><strong>Estimated batter:</strong> ${formatWeight(calc.batterWeight, unit, places)}</span>
      <span><strong>Estimated properties:</strong> Hardness ${formatNumber(calc.qualityProfile.hardness, 0)}, Cleansing ${formatNumber(calc.qualityProfile.cleansing, 0)}, Conditioning ${formatNumber(calc.qualityProfile.conditioning, 0)}, Bubbly ${formatNumber(calc.qualityProfile.bubbly, 0)}, Creamy ${formatNumber(calc.qualityProfile.creamy, 0)}</span>
    </div>
    ${notesMarkup}
  `;
}

function calculateAndRender() {
  updateWaterUI();
  lastCalculation = calculateRecipe();
  renderCalculation(lastCalculation);
}

function balanceOilWeights() {
  const rows = [...els.oilRows.querySelectorAll("tr")];
  const totalWeight = rows.reduce((sum, row) => sum + (Number(row.querySelector(".oil-weight").value) || 0), 0);
  const totalPercent = rows.reduce((sum, row) => sum + (Number(row.querySelector(".oil-percent-input").value) || 0), 0);

  if (totalWeight > 0 && totalPercent > 0) {
    rows.forEach(row => {
      const percent = Number(row.querySelector(".oil-percent-input").value) || 0;
      row.querySelector(".oil-weight").value = decimal(totalWeight * percent / 100, 2);
    });
  } else if (rows.length) {
    const equalPercent = decimal(100 / rows.length, 1);
    rows.forEach((row, index) => {
      row.querySelector(".oil-percent-input").value = index === rows.length - 1
        ? decimal(100 - equalPercent * (rows.length - 1), 1)
        : equalPercent;
    });
  }
  calculateAndRender();
}

function resetRecipe() {
  els.recipeName.value = "Lavender Dreams";
  els.unitSelect.value = "g";
  els.superfat.value = "5";
  els.waterMethod.value = "ratio";
  els.waterRatio.value = "2.4";
  els.lyeConcentration.value = "30";
  els.waterPercent.value = "33";
  els.fragranceLoad.value = "5";
  els.fragranceName.value = "Lavender & Chamomile";
  if (els.additiveSelect) els.additiveSelect.value = "Sugar";
  if (els.additiveRate) els.additiveRate.value = "1";
  if (els.additiveBase) els.additiveBase.value = "oils";
  els.batchNotes.value = "";
  setRows(starterRows);
}

function loadSavedRecipes() {
  try { return JSON.parse(localStorage.getItem("belLeisSoapRecipes") || "[]"); }
  catch { return []; }
}

function storeSavedRecipes() {
  localStorage.setItem("belLeisSoapRecipes", JSON.stringify(savedRecipes));
}

function saveCurrentRecipe() {
  const calc = calculateRecipe();
  if (calc.totalOils <= 0) {
    showTemporaryWarning("Add oil weights before saving the recipe.");
    return;
  }
  const freeLimit = 3;
  if (savedRecipes.length >= freeLimit) {
    showTemporaryWarning("Free mode saves up to 3 recipes. Delete one saved recipe or treat unlimited saves as a future Pro feature.");
    return;
  }
  savedRecipes.unshift({
    id: crypto.randomUUID ? crypto.randomUUID() : String(Date.now()),
    name: calc.settings.recipeName,
    settings: calc.settings,
    rows: calc.rows,
    totals: {
      totalOils: calc.totalOils,
      lyeAfterSuperfat: calc.lyeAfterSuperfat,
      water: calc.water,
      fragrance: calc.fragrance
    },
    createdAt: calc.createdAt
  });
  storeSavedRecipes();
  renderSavedRecipes();
}

function loadRecipe(recipeId) {
  const recipe = savedRecipes.find(item => item.id === recipeId);
  if (!recipe) return;
  els.recipeName.value = recipe.settings.recipeName || recipe.name;
  els.unitSelect.value = recipe.settings.unit || "g";
  els.superfat.value = recipe.settings.superfat ?? 5;
  els.waterMethod.value = recipe.settings.waterMethod || "ratio";
  els.waterRatio.value = recipe.settings.waterRatio ?? 2.4;
  els.lyeConcentration.value = recipe.settings.lyeConcentration ?? 30;
  els.waterPercent.value = recipe.settings.waterPercent ?? 33;
  els.fragranceLoad.value = recipe.settings.fragranceLoad ?? 5;
  els.fragranceName.value = recipe.settings.fragranceName || "";
  if (els.additiveSelect) els.additiveSelect.value = recipe.settings.additiveName || "Sugar";
  if (els.additiveRate) els.additiveRate.value = recipe.settings.additiveRate ?? 1;
  if (els.additiveBase) els.additiveBase.value = recipe.settings.additiveBase || "oils";
  els.batchNotes.value = recipe.settings.batchNotes || "";
  setRows(recipe.rows.map(row => ({
    name: row.selectName || row.name,
    customName: row.customName || "",
    percent: row.percent,
    weight: row.weight,
    sap: row.sap
  })));
  document.querySelector("#calculator").scrollIntoView({ behavior: "smooth" });
}

function deleteRecipe(recipeId) {
  savedRecipes = savedRecipes.filter(item => item.id !== recipeId);
  storeSavedRecipes();
  renderSavedRecipes();
}

function renderSavedRecipes() {
  if (!savedRecipes.length) {
    els.savedRecipes.innerHTML = `<div class="empty-vault">No saved recipes yet. Calculate a recipe, then press “Save recipe.”</div>`;
    return;
  }

  els.savedRecipes.innerHTML = savedRecipes.map(recipe => {
    const unit = recipe.settings.unit || "g";
    const places = unit === "g" ? 1 : 2;
    const date = new Date(recipe.createdAt).toLocaleDateString();
    return `
      <article class="vault-card">
        <h3>${escapeHtml(recipe.name)}</h3>
        <p>${date}</p>
        <p>Total oils: ${formatWeight(recipe.totals.totalOils, unit, places)}</p>
        <p>NaOH: ${formatWeight(recipe.totals.lyeAfterSuperfat, unit, places)} · Water: ${formatWeight(recipe.totals.water, unit, places)}</p>
        <div class="vault-actions">
          <button type="button" data-load="${recipe.id}">Load</button>
          <button type="button" data-delete="${recipe.id}">Delete</button>
        </div>
      </article>
    `;
  }).join("");

  els.savedRecipes.querySelectorAll("[data-load]").forEach(button => button.addEventListener("click", () => loadRecipe(button.dataset.load)));
  els.savedRecipes.querySelectorAll("[data-delete]").forEach(button => button.addEventListener("click", () => deleteRecipe(button.dataset.delete)));
}

function populateAdditiveSelect() {
  if (!els.additiveSelect) return;
  els.additiveSelect.innerHTML = "";
  additiveLibrary.forEach(item => {
    const option = document.createElement("option");
    option.value = item.name;
    option.textContent = `${item.name} — ${item.category}`;
    els.additiveSelect.appendChild(option);
  });
  els.additiveSelect.value = "Sugar";
  updateAdditiveDefaults();
}

function updateAdditiveDefaults() {
  const item = getIngredientByName(els.additiveSelect?.value);
  if (!item) return;
  if (Number.isFinite(item.defaultRate)) els.additiveRate.value = item.defaultRate;
  if (item.base && els.additiveBase) els.additiveBase.value = item.base;
}

function renderIngredientLibrary() {
  if (!els.ingredientCards) return;
  const query = normalize(els.ingredientSearch.value);
  const category = els.ingredientCategoryFilter.value;
  const results = ingredientLibrary.filter(item => {
    const haystack = normalize([item.name, item.category, item.color, item.usage, item.notes, ...(item.aliases || []), ...(item.contributes || [])].join(" "));
    const categoryMatch = category === "all" || item.category === category;
    return categoryMatch && (!query || haystack.includes(query));
  });

  els.ingredientCards.innerHTML = results.map(item => `
    <button class="ingredient-card" type="button" data-ingredient="${escapeHtml(item.name)}">
      <span class="ingredient-category">${escapeHtml(item.category)}</span>
      <strong>${escapeHtml(item.name)}</strong>
      <small>${Number.isFinite(item.sapNaoh) ? `NaOH SAP ${formatNumber(item.sapNaoh, 3)}` : item.usage || "Usage varies"}</small>
      <span class="ingredient-card-color">${escapeHtml(item.color || "Color varies")}</span>
    </button>
  `).join("") || `<div class="empty-vault">No ingredient matches that search yet. Try another term, or add it to the future custom library.</div>`;

  els.ingredientCards.querySelectorAll("[data-ingredient]").forEach(button => {
    button.addEventListener("click", () => showIngredientDetail(button.dataset.ingredient));
  });

  if (results.length) showIngredientDetail(results[0].name, false);
}

function showIngredientDetail(name, scroll = false) {
  const item = getIngredientByName(name);
  if (!item || !els.ingredientDetail) return;
  els.ingredientDetail.innerHTML = ingredientDetailMarkup(item);
  if (scroll) els.ingredientDetail.scrollIntoView({ behavior: "smooth", block: "nearest" });
}

function populateCategoryFilter() {
  if (!els.ingredientCategoryFilter) return;
  const categories = [...new Set(ingredientLibrary.map(item => item.category).filter(Boolean))].sort();
  categories.forEach(category => {
    const option = document.createElement("option");
    option.value = category;
    option.textContent = category;
    els.ingredientCategoryFilter.appendChild(option);
  });
}

function renderPropertiesGuide() {
  if (!els.propertiesGuide) return;
  els.propertiesGuide.innerHTML = propertyGuide.map(item => `
    <article class="property-card">
      <h3>${escapeHtml(item.term)}</h3>
      <p>${escapeHtml(item.meaning)}</p>
      <p><strong>In practice:</strong> ${escapeHtml(item.practical)}</p>
    </article>
  `).join("");
}

function printHtml(title, body) {
  const popup = window.open("", "_blank");
  if (!popup) {
    window.print();
    return;
  }
  popup.document.write(`<!doctype html><html><head><title>${escapeHtml(title)}</title><style>
    body{font-family:Georgia,serif;color:#2b143a;margin:32px;line-height:1.45}h1,h2,h3{color:#35104f}h1{border-bottom:3px solid #b47d27;padding-bottom:8px}.grid{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:14px}.card{border:1px solid #d9c1ec;border-radius:14px;padding:14px;background:#fffaf1;break-inside:avoid}small{color:#6c5175}.chip{display:inline-block;border:1px solid #d6b25f;border-radius:999px;padding:3px 8px;margin:3px;font-size:12px}@media print{body{margin:18mm}.grid{grid-template-columns:1fr 1fr}}
  </style></head><body>${body}</body></html>`);
  popup.document.close();
  popup.focus();
  popup.print();
}

function printPropertiesGuide() {
  const body = `<h1>Bel Lei's Soap Properties Guide</h1><p>A printable plain-English guide to soap calculator numbers and fatty acids.</p><div class="grid">${propertyGuide.map(item => `<section class="card"><h2>${escapeHtml(item.term)}</h2><p>${escapeHtml(item.meaning)}</p><p><strong>In practice:</strong> ${escapeHtml(item.practical)}</p></section>`).join("")}</div>`;
  printHtml("Bel Lei's Soap Properties Guide", body);
}

function printIngredientLibrary() {
  const body = `<h1>Bel Lei's Ingredient Library</h1><p>Starter reference library. Verify supplier SAP values and usage rates before production.</p><div class="grid">${ingredientLibrary.map(item => `<section class="card"><h2>${escapeHtml(item.name)}</h2><small>${escapeHtml(item.category)}${Number.isFinite(item.sapNaoh) ? ` · NaOH SAP ${formatNumber(item.sapNaoh, 3)}` : ""}</small><p><strong>Color:</strong> ${escapeHtml(item.color || "Varies")}</p><p><strong>Use:</strong> ${escapeHtml(item.usage || "Varies")}</p><p>${(item.contributes || []).map(chip => `<span class="chip">${escapeHtml(chip)}</span>`).join("")}</p><p>${escapeHtml(item.notes || "Test small batches.")}</p></section>`).join("")}</div>`;
  printHtml("Bel Lei's Ingredient Library", body);
}

function showTemporaryWarning(message) {
  els.warnings.hidden = false;
  els.warnings.innerHTML = `<p>${escapeHtml(message)}</p>`;
  window.setTimeout(() => calculateAndRender(), 3200);
}

function bindEvents() {
  els.recipeForm.addEventListener("submit", event => {
    event.preventDefault();
    calculateAndRender();
  });

  [
    els.recipeName, els.unitSelect, els.superfat, els.waterMethod, els.waterRatio, els.lyeConcentration,
    els.waterPercent, els.fragranceLoad, els.fragranceName, els.additiveSelect, els.additiveRate,
    els.additiveBase, els.batchNotes
  ].filter(Boolean).forEach(input => {
    input.addEventListener("input", calculateAndRender);
    input.addEventListener("change", calculateAndRender);
  });

  els.additiveSelect?.addEventListener("change", () => {
    updateAdditiveDefaults();
    calculateAndRender();
  });

  els.ingredientSearch?.addEventListener("input", renderIngredientLibrary);
  els.ingredientCategoryFilter?.addEventListener("change", renderIngredientLibrary);
  els.printPropertiesGuide?.addEventListener("click", printPropertiesGuide);
  els.printIngredientLibrary?.addEventListener("click", printIngredientLibrary);

  els.addOil.addEventListener("click", () => addOilRow({ name: "Custom oil / butter", percent: 0, weight: 0, sap: 0.134 }));
  els.balanceOils.addEventListener("click", balanceOilWeights);
  els.saveRecipe.addEventListener("click", saveCurrentRecipe);
  els.printRecipe.addEventListener("click", () => window.print());
  els.resetRecipe.addEventListener("click", resetRecipe);

  document.querySelectorAll("[data-scroll-to]").forEach(button => {
    button.addEventListener("click", () => {
      const target = document.querySelector(`#${button.dataset.scrollTo}`);
      if (target) target.scrollIntoView({ behavior: "smooth" });
    });
  });

  els.mobileMenuButton.addEventListener("click", () => {
    const isOpen = els.navLinks.classList.toggle("is-open");
    els.mobileMenuButton.setAttribute("aria-expanded", String(isOpen));
  });

  els.navLinks.querySelectorAll("a").forEach(link => {
    link.addEventListener("click", () => {
      els.navLinks.classList.remove("is-open");
      els.mobileMenuButton.setAttribute("aria-expanded", "false");
    });
  });
}

function registerServiceWorker() {
  if ("serviceWorker" in navigator) {
    navigator.serviceWorker.register("service-worker.js").catch(() => {});
  }
}

populateCategoryFilter();
populateAdditiveSelect();
renderPropertiesGuide();
bindEvents();
setRows(starterRows);
renderSavedRecipes();
renderIngredientLibrary();
calculateAndRender();
registerServiceWorker();
